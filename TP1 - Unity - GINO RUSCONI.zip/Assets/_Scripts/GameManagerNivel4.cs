using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManagerNivel4 : MonoBehaviour
{
    public int killsToWin;
    public int NextLvl;
    public float timeToWin;
    EnemyManager enemymanager;
    Player player;
    TimeManager timemanager;
    private void Awake()
    {
        GameObject enemymanagerGO = GameObject.Find("EnemyManager");
        enemymanager = enemymanagerGO.GetComponent<EnemyManager>();

        GameObject timemanagerGO = GameObject.Find("TimeManager");
        timemanager = timemanagerGO.GetComponent<TimeManager>();

        GameObject playerGO = GameObject.Find("Player");
        player = playerGO.GetComponent<Player>();
    }
    private void Update()
    {
        if (enemymanager.enemysDie >= killsToWin)
        {
            if (timemanager.timeFromStart >= timeToWin)
            {
                SceneManager.LoadScene(NextLvl);
            }
        }
        else if (!player.isPlayerHealth)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }
}
