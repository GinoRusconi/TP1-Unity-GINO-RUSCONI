using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Life : MonoBehaviour
{
    public int maxLife = 100;

    private int currentLife;

    private void Awake()
    {
        currentLife = maxLife;
    }

    private void Update()
    {
        if (currentLife <= 0)
        {
            SendMessage("Mori");
        }
    }

    public void TakeDamage(int dmg)
    {
        currentLife -= dmg;
        SendMessage("TakeDamageMe");
    }

}
