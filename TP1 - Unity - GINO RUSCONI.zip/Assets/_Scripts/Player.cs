using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public bool isPlayerHealth = true;
    Renderer _renderer;
    private void Awake()
    {
        _renderer = GetComponent<Renderer>();

    }
    void Mori()
    {
        isPlayerHealth = false;
    }

    public void TakeDamageMe()
    {
        Color.RGBToHSV(_renderer.material.color, out float H, out float S, out float V);
        _renderer.material.color = Color.HSVToRGB(H, S, V - 0.25f);
    }
    
}
