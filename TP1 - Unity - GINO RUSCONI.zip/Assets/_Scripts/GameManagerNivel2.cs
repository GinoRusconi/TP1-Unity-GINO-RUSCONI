using UnityEngine.SceneManagement;
using UnityEngine;

public class GameManagerNivel2 : MonoBehaviour
{
    public int killsToWin;
    public int NextLvl;
    EnemyManager enemymanager;
    Player player;
    
    private void Awake()
    {
        GameObject enemymanagerGO = GameObject.Find("EnemyManager");
        enemymanager = enemymanagerGO.GetComponent<EnemyManager>();

        GameObject playerGO = GameObject.Find("Player");
        player = playerGO.GetComponent<Player>();
    }
    private void Update()
    {
        if (enemymanager.enemysDie >= killsToWin)
        {
            SceneManager.LoadScene(NextLvl);
        }
        else if (!player.isPlayerHealth)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }

    
}
