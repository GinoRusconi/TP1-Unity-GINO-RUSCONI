using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wall : MonoBehaviour
{
    Renderer _renderer;

    private void Awake()
    {
        _renderer = GetComponent<Renderer>();
    }
    public void Mori()
    {
        Destroy(gameObject);
    }

    public void TakeDamageMe()
    {
        Color.RGBToHSV(_renderer.material.color, out float H, out float S, out float V);
        _renderer.material.color = Color.HSVToRGB(H, S, V - 0.05f);
    }
}
