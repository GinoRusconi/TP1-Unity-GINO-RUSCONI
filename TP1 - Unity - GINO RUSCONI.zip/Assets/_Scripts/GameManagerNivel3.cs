using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManagerNivel3 : MonoBehaviour
{
    TimeManager timemanager;
    Player player;
    public float timeToWin;
    public int NextLvl;
    private void Awake()
    {
        GameObject timemanagerGO = GameObject.Find("TimeManager");
        timemanager = timemanagerGO.GetComponent<TimeManager>();
        GameObject playerGO = GameObject.Find("Player");
        player = playerGO.GetComponent<Player>();
    }


    private void Update()
    {

        if (timemanager.timeFromStart >= timeToWin)
        {
            SceneManager.LoadScene(NextLvl);
        }

        else if (!player.isPlayerHealth)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }
}

